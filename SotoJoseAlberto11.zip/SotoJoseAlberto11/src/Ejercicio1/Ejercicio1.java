/*
 * Descripción: Imprimir una línea por pantalla
 * Autor: Jose Alberto Soto Mas
 * Fecha: 23/09/25
 */
package Ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {
		System.out.println ("Este es mi primer programa Java");
	}

}
