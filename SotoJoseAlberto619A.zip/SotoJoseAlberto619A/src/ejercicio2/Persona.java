package ejercicio2;

public class Persona {
	String dni;
	String nombre;
	String apellidos;
	byte edad;
}
