/*
 * Descripción: Manejo básico de operadores
 * Autor: Jose Alberto Soto Mas
 * Fecha: 01/10/25
 */
package ejercicio1;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);//Inicialización de la entrada de datos
		
		String nombre;//Declaración de variable
		System.out.print("Introduce tu nombre: ");
		nombre = teclado.nextLine();//Petición y asignación de un dato introducido en el teclado
		
		String apellidos;
		System.out.print("Introduce tus apellidos: ");
		apellidos = teclado.nextLine();
		
		String fechaNacimiento;
		System.out.print("Introduce tu fecha de nacimiento: ");
		fechaNacimiento = teclado.nextLine();
		
		float salarioBruto;
		System.out.print("Introduce tu salario bruto: ");
		salarioBruto = teclado.nextFloat();
		
		byte annosTrabajo;
		System.out.print("Introduce cuantos años que has estado trabajando en la empresa: ");
		annosTrabajo = teclado.nextByte();
		
		float salarioNeto = salarioBruto - salarioBruto/100 * 15;//Cálculo del salario neto (salario bruto menos el 15% de IRPF
		float aumento = salarioNeto/100 * (2*annosTrabajo);//Cálculo del aumento (2% del salario neto por año trabajado)
		float salarioTotal = salarioNeto + aumento;//Cálculo del salario total
		System.out.println("Estimad@ " + nombre + " " + apellidos + ", su salario bruto es " + salarioBruto + ", teniendo en\r\n"
				+ "cuenta un IRPF del 15% su salario neto es " + salarioNeto + ".");
		System.out.println("");
		System.out.println("Debido a sus " + annosTrabajo + " años trabajando en la empresa\r\n"
				+ "su salario se incrementará en un 2% por cada año. El aumento es de\r\n"
				+ aumento + " y el salario total es " + salarioTotal);
	}

}
