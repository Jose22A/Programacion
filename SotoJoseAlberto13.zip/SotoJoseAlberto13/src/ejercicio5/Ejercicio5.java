/*
 * Descripción: Uso de la clase Math para varias operaciones
 * Autor: Jose Alberto Soto Mas
 * Fecha: 01/10/25
 */
package ejercicio5;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);//Inicialización de la entrada de datos
		
		double num1, num2;//Declaración de variables
		System.out.print("Introduce un número: ");
		num1 = teclado.nextDouble();//Petición y asignación de un dato introducido en el teclado
		System.out.print("Introduce otro número: ");
		num2 = teclado.nextDouble();
		
		double numMin, num1ElevNum2, sqrtNum1, randNum2;
		numMin = Math.min(num1, num2);
		num1ElevNum2 = Math.pow(num1, num2);
		sqrtNum1 = Math.sqrt(num1);
		randNum2 = Math.random() * num2;
		System.out.println("El menor de los dos números es " + numMin);
		System.out.println("El primer número elevado al segundo es " + num1ElevNum2);
		System.out.println("La raiz cuadrada del primer número es " + sqrtNum1);
		System.out.println("Un valor random del segundo número es " + randNum2);
	}

}
