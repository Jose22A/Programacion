/*
 * Descripción: Declarar, inicializar y mostrar distintos tipos de variables por pantalla
 * Autor: Jose Alberto Soto Mas
 * Fecha: 26/09/25
 */
package ejercicio3;

public class Ejercicio3 {
	
	public static void main(String[] args) {
		int num1 = 1, num2 = 1; //Declaración e inicialización de variables tipo int
		char char1 = 'a', char2 = 'b'; //Declaración e inicialización de variables tipo char
		String Cargo = "programador", Nombre = "Jose Alberto"; //Declaración e inicialización de variables tipo String
		System.out.println("Valor de las variables tipo int: " + num1 + " y " + num2);
		System.out.println("Bienvenido, " + Cargo + " " + Nombre);
	}

}
