/*
 * Descripción: Manejo de bucles
 * Autor: Jose Alberto Soto Mas
 * Fecha: 15/10/25
 */
package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		int num = 100;
		do {
			System.out.println(num);
			num = num - 1;
		} while (num >= 1);
	}

}
