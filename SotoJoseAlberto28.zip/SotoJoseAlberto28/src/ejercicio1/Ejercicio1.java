/*
 * Descripción: Manejo de bucles
 * Autor: Jose Alberto Soto Mas
 * Fecha: 15/10/25
 */
package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {
		int num = 1;
		while (num <= 100) {
			System.out.println(num);
			num = num + 1;
		}
	}

}
