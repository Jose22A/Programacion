/*
 * Descripción: Manejo de bucles
 * Autor: Jose Alberto Soto Mas
 * Fecha: 15/10/25
 */
package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) {
		int num = 1;
		do {
			System.out.println(num);
			num = num + 1;
		} while (num <= 100);
	}

}
